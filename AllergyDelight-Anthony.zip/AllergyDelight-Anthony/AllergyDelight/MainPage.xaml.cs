﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Xamarin.Forms;

namespace AllergyDelight
{
    public partial class MainPage : ContentPage
    {
        public MainPage()
        {
            InitializeComponent();
        
            
        }

      




        private async void filter_clicked(object sender, EventArgs e)
        {

        }
        private async void restaurants_clicked(object sender, EventArgs e)
        {

        }
        private async void tools_clicked(object sender, EventArgs e)
        {

        }







        

    }


   




}
